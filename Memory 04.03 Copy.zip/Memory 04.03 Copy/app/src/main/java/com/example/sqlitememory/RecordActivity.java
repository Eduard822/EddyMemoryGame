package com.example.sqlitememory;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class RecordActivity extends AppCompatActivity {

    ArrayAdapter<String> adapter;
    Button btn_black;
    List<Object> PlayerSName;

    EditText Email, Password;

    TextView tvAttemps;


    Button btn_back_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);

        PlayerSName = new ArrayList<Object>();

        tvAttemps = (TextView) findViewById(R.id.numattemp);

        Email = (EditText) findViewById(R.id.txtEmail);
        Password = (EditText) findViewById(R.id.txtPwd);

        btn_back_details = (Button) findViewById(R.id.back_details);

        List<Player>players = PlayerHelper.getInstance().ReadAll();

        for (int i = 0; i < players.size(); i++) {
            PlayerSName.add(i, players.get(i).name);
        }


        // получаем элемент ListView
       ListView PlayersList = findViewById(R.id.list_score);

        // устанавливаем для списка адаптер
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, PlayerSName);
        PlayersList.setAdapter(adapter);

        btn_black = (Button) findViewById(R.id.btn_back);
        btn_black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        PlayersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
//
                //PlayerHelper.getInstance().Delete(players.get(pos).id);
                // создание объекта Intent для запуска PlayerDetails
                Intent intent = new Intent(getApplicationContext(), PlayerDetails.class);
                // передача объекта с ключом "player" и со всеми значениями игрока
                // intent.putExtra("player", players.get(pos));
                startActivity(intent);
                //openDialog();
               // openDialog();

            }
        });


    }

    public void openDialog() {
        final Dialog dialog = new Dialog(RecordActivity.this);
        dialog.setContentView(R.layout.delete);
        dialog.setCancelable(false);
        dialog.show();
    }


}