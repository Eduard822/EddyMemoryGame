package com.example.sqlitememory;

import java.io.Serializable;

public class Player implements Serializable {
    public Long id;
    public String name;
    public String email;
    public String password;

    public Integer isAdmin;

    public Integer best_time_4x4;
    public Integer best_time_4x5;
    public Integer best_time_4x6;
    public Integer best_time_5x6;
    public Integer best_time_6x6;

    public Integer best_try_4x4;
    public Integer best_try_4x5;
    public Integer best_try_4x6;
    public Integer best_try_5x6;
    public Integer best_try_6x6;


    public Integer game_total;
    public Integer game_win;
    public Integer time_total;
}
