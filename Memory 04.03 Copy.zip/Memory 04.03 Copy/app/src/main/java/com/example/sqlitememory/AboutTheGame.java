package com.example.sqlitememory;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AboutTheGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_the_game2);
    }
}