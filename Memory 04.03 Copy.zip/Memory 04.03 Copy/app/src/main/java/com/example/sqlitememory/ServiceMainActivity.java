package com.example.sqlitememory;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ServiceMainActivity extends AppCompatActivity {

    Button btnPlay; // מדליקים את הרדיו
    MediaPlayer mediaPlayer;
    boolean prepared = false;
    boolean started = false;
    String streams = "http://199.180.75.118:80/stream";

    boolean isPlay;


    //String strLink;
    //Intent serviceIntent;
    TextView timeView;
    Date date;
    int minutes;
    Thread myTime, thRunStop;
    BroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_main);
        date = new Date();
        timeView = (TextView) findViewById(R.id.time_View);
        myTime = new Thread(mUpdateClockTask);
        thRunStop = new Thread(runStop);
        thRunStop.start();
        myTime.start();

        isPlay = false;
        //serviceIntent = new Intent(this, PlayService.class);
        btnPlay = (Button) findViewById(R.id.butPlay);
        btnPlay.setEnabled(false);
        btnPlay.setText("LOADING");
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        new PlayerTask().execute(streams);

        date = new Date();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (started) {
                    started = false;
                    mediaPlayer.pause();
                    btnPlay.setText("PLAY");
                } else {
                    started = true;
                    mediaPlayer.start();
                    btnPlay.setText("PAUSE");
                }
            }
        });
    }

    /*
    private void btnPlayClick() {
        if (!isPlay) {
            isPlay = true;
            btnPlay.setText("STOP");
            playAudio();
        } else {
            isPlay = false;
            btnPlay.setText("PLAY");
            stopAudio();
        }
    }

     */



    /*
    private void stopAudio() {
        try {
            stopService(serviceIntent);
            Toast.makeText(this, "Audio have stopped", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

     */

    /*
    private void playAudio() {
        //strLink = " https://streams.ilovemusic.de/iloveradio14.mp3 ";
        // strLink= "http://stream.radioreklama.bg:80/radio1rock128";
        strLink ="https://jazzlounge.ice.infomaniak.ch/jazzlounge-high.mp3";
        //strLink ="https://music.xn--41a.ws/song/45698-miyagi-%D1%8D%D0%BD%D0%B4%D1%88%D0%BF%D0%B8%D0%BB%D1%8C-freedom";
        serviceIntent.putExtra("link", strLink);
        try {
            startService(serviceIntent);
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

     */


    private class PlayerTask extends AsyncTask<String, Void, Boolean> {
        @Override
        public Boolean doInBackground(String... strings) {
            try {
                mediaPlayer.setDataSource(strings[0]);
                mediaPlayer.prepare();
                prepared = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return prepared;
        }

        /*
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            btnPlay.setEnabled(true);
            btnPlay.setText("PLAY");
        }

         */

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            btnPlay.setEnabled(true);
            btnPlay.setText("PLAY");
        }

        protected void onPause() {
            super.onPreExecute();
            if (started == true) mediaPlayer.pause();
        }

        protected void onResume() {
            super.onProgressUpdate();
            if (started == false) mediaPlayer.start();
        }

        protected void onDestroy() {
            super.onCancelled();
            if (prepared) mediaPlayer.release();
        }
    }


    private Runnable runStop = new Runnable() {
        public void run() {
            while (true) {
                Calendar cal = Calendar.getInstance();
                minutes = cal.get(Calendar.MINUTE);
                try {
                    System.out.println("minutes:" + minutes);
                    Thread.sleep(5000);
                    if (minutes == 5) {
                        started = false;
                        mediaPlayer.pause();
                        btnPlay.setText("PLAY");
                    }
                    if (minutes == 0) {
                        started = true;
                        mediaPlayer.start();
                        btnPlay.setText("PAUSE");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };


    private final SimpleDateFormat sdfWatchTime = new SimpleDateFormat("HH:mm");//format

    @Override
    public void onStart() {
        super.onStart();
        broadcastReceiver = new BroadcastReceiver() {
            public void onReceive(Context ctx, Intent intent) {
                if (intent.getAction().compareTo(Intent.ACTION_TIME_TICK) == 0)
                    timeView.setText(sdfWatchTime.format(new Date()));
            }
        };

        registerReceiver(broadcastReceiver, new IntentFilter(Intent.ACTION_TIME_TICK));
    }

    @Override
    public void onStop() {
        super.onStop();
        if (broadcastReceiver != null)
            unregisterReceiver(broadcastReceiver);
    }

    public void setTime() {
        Calendar cal = Calendar.getInstance();
        if (DateFormat.is24HourFormat(this)) {
            int hours = cal.get(Calendar.HOUR_OF_DAY);
            timeView.setText((hours < 10 ? "0" + hours : hours) + ":"
                    + (minutes < 10 ? "0" + minutes : minutes));
        } else {
            int hours = cal.get(Calendar.HOUR);
            timeView.setText(hours + ":" + (minutes < 10 ? "0" + minutes : minutes) + " "
                    + new DateFormatSymbols().getAmPmStrings()[cal.get(Calendar.AM_PM)]);
        }
    }

    private Runnable mUpdateClockTask = new Runnable() {
        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            setTime();
        }
    };
}