package com.example.sqlitememory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


public class PlayerDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "memory_game";
    private static final String TABLE_PLAYERS = "players";


    // Пара - по которой мы индифицируем пользователя
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_IS_ADMIN = "is_admin";

    //
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_ID = "id";


    /**
     * Данные по игре
     */

    // лучшее время игрока на кажом поле
    private static final String COLUMN_TIME_PAD_4x4 = "best_time_4x4";
    private static final String COLUMN_TIME_PAD_4x5 = "best_time_4x5";
    private static final String COLUMN_TIME_PAD_4x6 = "best_time_4x6";
    private static final String COLUMN_TIME_PAD_5x6 = "best_time_5x6";
    private static final String COLUMN_TIME_PAD_6x6 = "best_time_6x6";

    // лучшее количество попыток (ходов) игрока на кажом поле
    private static final String COLUMN_TRY_PAD_4x4 = "best_try_4x4";
    private static final String COLUMN_TRY_PAD_4x5 = "best_try_4x5";
    private static final String COLUMN_TRY_PAD_4x6 = "best_try_4x6";
    private static final String COLUMN_TRY_PAD_5x6 = "best_try_5x6";
    private static final String COLUMN_TRY_PAD_6x6 = "best_try_6x6";

    // Сколько игр игрок начал
    private static final String COLUMN_GAME_TOTAL = "game_total";
    // Сколько игр игрок выиграл (прошел)
    private static final String COLUMN_GAME_WIN = "game_win";

    // Сколько времени игрок провел вообще в игре
    private static final String COLUMN_TIME_TOTAL = "time_total";

    // Версия изменений таблиц
    private static final int DATABASE_VERSION = 1;


    // Конструктор
    // Принимаем контекст на базу данных всего телефона
    public PlayerDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Создать нового игрока в базе
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCommand = "CREATE TABLE " + TABLE_PLAYERS + " " +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NAME + " TEXT, " +
                COLUMN_EMAIL + " TEXT, " + //  ключ по email
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_IS_ADMIN + " INTEGER, " + // 0 если просто игрок - 1  если админ

                COLUMN_TIME_PAD_4x4 + " INTEGER, " +
                COLUMN_TIME_PAD_4x5 + " INTEGER, " +
                COLUMN_TIME_PAD_4x6 + " INTEGER, " +
                COLUMN_TIME_PAD_5x6 + " INTEGER, " +
                COLUMN_TIME_PAD_6x6 + " INTEGER, " +

                COLUMN_TRY_PAD_4x4 + " INTEGER, " +
                COLUMN_TRY_PAD_4x5 + " INTEGER, " +
                COLUMN_TRY_PAD_4x6 + " INTEGER, " +
                COLUMN_TRY_PAD_5x6 + " INTEGER, " +
                COLUMN_TRY_PAD_6x6 + "  INTEGER, " +

                COLUMN_GAME_TOTAL + " INTEGER, " +
                COLUMN_GAME_WIN + " INTEGER, " +
                COLUMN_TIME_TOTAL + " INTEGER " +


                " )";
        db.execSQL(sqlCommand);

        db.execSQL(
                "INSERT INTO " + TABLE_PLAYERS + " (" + COLUMN_NAME + ", " + COLUMN_EMAIL + "," + COLUMN_PASSWORD + ")" +
                        "VALUES ('Admin', 'admin@admin@com','12345')"
        );

    }

    SQLiteDatabase db;

    // Создать нового игрока в базе
    public long Create(Player newPlayer) {

        // База с которой мы собрались работать
        db = this.getWritableDatabase();

        // Управление данными для внесения в базу
        ContentValues values = new ContentValues();

        // Внесение данных

        values.put(COLUMN_NAME, newPlayer.name);
        values.put(COLUMN_EMAIL, newPlayer.email);
        values.put(COLUMN_PASSWORD, newPlayer.password);

        values.put(COLUMN_TIME_PAD_4x4, newPlayer.best_time_4x4);
        values.put(COLUMN_TIME_PAD_4x5, newPlayer.best_time_4x5);
        values.put(COLUMN_TIME_PAD_4x6, newPlayer.best_time_4x6);
        values.put(COLUMN_TIME_PAD_5x6, newPlayer.best_time_5x6);
        values.put(COLUMN_TIME_PAD_6x6, newPlayer.best_time_6x6);

        values.put(COLUMN_TRY_PAD_4x4, newPlayer.best_try_4x4);
        values.put(COLUMN_TRY_PAD_4x5, newPlayer.best_try_4x5);
        values.put(COLUMN_TRY_PAD_4x6, newPlayer.best_try_4x6);
        values.put(COLUMN_TRY_PAD_5x6, newPlayer.best_try_5x6);
        values.put(COLUMN_TRY_PAD_6x6, newPlayer.best_try_6x6);

        values.put(COLUMN_GAME_TOTAL, newPlayer.game_total);
        values.put(COLUMN_GAME_WIN, newPlayer.game_win);
        values.put(COLUMN_TIME_TOTAL, newPlayer.time_total);

        // Выполним операцию по внесению данных
        long newId = db.insert(TABLE_PLAYERS, null, values);

        db.close();

        return newId;
    }

    // Получить список всех игроков
    public List<Player> ReadAll() {
        List<Player> res = new ArrayList<Player>();
        String sqlCommand = "SELECT * FROM " + TABLE_PLAYERS;
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.rawQuery(sqlCommand, null);
        if (c.moveToFirst()) {
            do {
                Player p = new Player();
                p.id = c.getLong(0);
                p.name = c.getString(1);
                p.email = c.getString(2);
                p.password = c.getString(3);
                p.isAdmin = c.getInt(4);

                p.best_time_4x4 = c.getInt(5);
                p.best_time_4x5 = c.getInt(6);
                p.best_time_4x6 = c.getInt(7);
                p.best_time_5x6 = c.getInt(8);
                p.best_time_6x6 = c.getInt(9);

                p.best_try_4x4 = c.getInt(10);
                p.best_try_4x5 = c.getInt(11);
                p.best_try_4x6 = c.getInt(12);
                p.best_try_5x6 = c.getInt(13);
                p.best_try_6x6 = c.getInt(14);

                p.game_total = c.getInt(15);
                p.game_win = c.getInt(16);
                p.time_total = c.getInt(17);

                res.add(p);
            } while (c.moveToNext());
        }
        return res;
    }


    //Получить игрока по email и пароль
    public Player CheckUser(String email, String password) {
//        String sqlCommand = "SELECT * FROM " + TABLE_PLAYERS + " WHERE " + COLUMN_EMAIL + "='" + email +
//                "' AND " + COLUMN_PASSWORD + "='" + password +"'";
        // Строим запрос, вставляя ? в места, где должны быть параметры
        // конкретно email =  и password =
        String sqlCommand = "SELECT * FROM " + TABLE_PLAYERS + " WHERE " + COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=? ";
        SQLiteDatabase db = this.getWritableDatabase();
        //  отправляем в абзу - с учетом email  и password которые ввел пользователь
        Cursor c = db.rawQuery(sqlCommand, new String[]{email, password});

        // Если курсор не был создан вообще - закрываем соединение
        // игрока нет - значит возвращаем null
        if (c == null) {
            db.close();
            return null;
        }
        // читаем ответ
        c.moveToFirst();
        // если количество строк в ответе от базы даннх не 1 - значит что то пошло не так
        // например пользователь не зарегистрирован или он ошибся в воде
        if (c.getCount() != 1) {
            db.close();
            return null;
        }

        //  один пользователь - мы его записыаем, как текущего и возврещаем из базы
        Player res = new Player();//результат
        res.id = c.getLong(0);
        res.name = c.getString(1);
        res.email = c.getString(2);
        res.password = c.getString(3);

        res.isAdmin = c.getInt(4);

        res.best_time_4x4 = c.getInt(5);
        res.best_time_4x5 = c.getInt(6);
        res.best_time_4x6 = c.getInt(7);
        res.best_time_5x6 = c.getInt(8);
        res.best_time_6x6 = c.getInt(9);

        res.best_try_4x4 = c.getInt(10);
        res.best_try_4x5 = c.getInt(11);
        res.best_try_4x6 = c.getInt(12);
        res.best_try_5x6 = c.getInt(13);
        res.best_try_6x6 = c.getInt(14);

        res.game_total = c.getInt(15);
        res.game_win = c.getInt(16);
        res.time_total = c.getInt(17);

        db.close();


        return res;

    }


    // Получить игрока по id
    public Player Read(long id) {
        Player res = new Player();

        String sqlCommand = "SELECT * FROM " + TABLE_PLAYERS + " WHERE id=" + id;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(sqlCommand, null);

        db.close();

        if (c == null) return null;

        c.moveToFirst();

        res.id = c.getLong(0);
        res.name = c.getString(1);
        res.email = c.getString(2);
        res.password = c.getString(3);

        res.isAdmin = c.getInt(4);

        res.best_time_4x4 = c.getInt(5);
        res.best_time_4x5 = c.getInt(6);
        res.best_time_4x6 = c.getInt(7);
        res.best_time_5x6 = c.getInt(8);
        res.best_time_6x6 = c.getInt(9);

        res.best_try_4x4 = c.getInt(10);
        res.best_try_4x5 = c.getInt(11);
        res.best_try_4x6 = c.getInt(12);
        res.best_try_5x6 = c.getInt(13);
        res.best_try_6x6 = c.getInt(14);

        res.game_total = c.getInt(15);
        res.game_win = c.getInt(16);
        res.time_total = c.getInt(17);

        return res;
    }

    // Обновить игрока в базе
    public boolean Update(Player upPlayer, int id) {
        return true;
    }

//    // Удалить игрока из базы по id
//    public Integer Delete(long idPlayer) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        return db.delete(TABLE_PLAYERS,
//                PlayerDBHelper.COLUMN_ID + "=" + idPlayer, null);
//    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLAYERS);
        onCreate(db);
    }
}
