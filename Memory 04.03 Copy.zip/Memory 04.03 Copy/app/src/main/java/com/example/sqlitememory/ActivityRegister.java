package com.example.sqlitememory;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityRegister extends AppCompatActivity {


    EditText Name, Email, Password;
    Button loginRegister;
    TextView lnkLogin;
    ImageView ivDetails;

    Button TakePic;//take a photo

    Player player;

    EditText LoginAfterRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);
        Name = (EditText) findViewById(R.id.txtRegName);
        Email = (EditText) findViewById(R.id.txtRegEmail);
        Password = (EditText) findViewById(R.id.txtRegPwd);

        player = new Player();
        ivDetails = (ImageView) findViewById(R.id.image);
        TakePic = (Button) findViewById(R.id.btntakepic);
        lnkLogin = (TextView) findViewById(R.id.lnkLogin);
//        TakePic.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                openCamera();
//            }
//        });

        loginRegister = (Button) findViewById(R.id.btnRegister);
        loginRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Registration();
            }
        });
        lnkLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == lnkLogin.getId()) {
                    Intent intent = new Intent(ActivityRegister.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        });


    }


    public void Registration() {
        String name = Name.getText().toString();
        String email = Email.getText().toString();
        String password = Password.getText().toString();

        Player player = new Player();
        player.name = name;
        player.email = email;
        player.password = password;

        Boolean isCreate = PlayerHelper.getInstance().Create(player);// создание игрока

        if (isCreate && hasConnection(getApplicationContext()))
            Toast.makeText(getApplicationContext(), "Player has registered", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(getApplicationContext(), "Error or No Network Connection", Toast.LENGTH_SHORT).show();
    }

    //игра работает только при включенном wifi, иначе игрок не сможет зайти в игру или зарегистрироваться
    public boolean hasConnection(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        wifiInfo = cm.getActiveNetworkInfo();
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        return false;
    }
}