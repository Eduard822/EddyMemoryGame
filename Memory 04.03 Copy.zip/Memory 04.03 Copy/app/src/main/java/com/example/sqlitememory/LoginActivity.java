package com.example.sqlitememory;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    TextView linkRegister;
    Button Login;

    EditText Email;
    EditText Password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        linkRegister = (TextView) findViewById(R.id.lnkRegister);

        Email = (EditText) findViewById(R.id.txtEmail);
        Password = (EditText) findViewById(R.id.txtPwd);

        Login = (Button) findViewById(R.id.btnLogin);
        linkRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ActivityRegister.class);
                startActivity(intent);
            }
        });



            Login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PlayerHelper ph = PlayerHelper.getInstance();//реализация (шаблон) одиночки
                    boolean isLogin = ph.CheckUser(Email.getText().toString(), Password.getText().toString());
                    if (isLogin && hasConnection(view.getContext())) {
                        Toast.makeText(getApplicationContext(), "Player login", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MemoriaActivity.class);
                        startActivity(intent);
                        Email.setText("");
                        Password.setText("");
                    } else {
                        Toast.makeText(getApplicationContext(), "Error or No Network Connection", Toast.LENGTH_SHORT).show();
                        Email.setText("");
                        Password.setText("");
                    }
                }
            });


    }

    //игра работает только при включенном wifi, иначе игрок не сможет зайти в игру или зарегистрироваться
    public boolean hasConnection(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        wifiInfo = cm.getActiveNetworkInfo();
        if (wifiInfo != null && wifiInfo.isConnected()) {
            return true;
        }
        return false;
    }


}
