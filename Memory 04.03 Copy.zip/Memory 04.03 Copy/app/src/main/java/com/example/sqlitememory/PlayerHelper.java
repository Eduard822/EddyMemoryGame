package com.example.sqlitememory;

import java.util.List;

public class PlayerHelper {
    // Интерфейс для работы с базой данных
    public static PlayerDBHelper db;
    private static PlayerHelper _instance;

    private PlayerHelper() {
    }

    public static PlayerHelper getInstance() {
        if (_instance == null) _instance = new PlayerHelper();
        return _instance;
    }

    // Текущий игрок
    public Player currentPlayer = null;


    // Этот метод будет вызываться каждый раз, когда игра завершилась
    // размер поля, на котором проходила игра
    // время, которое потратил пользователь на очередную игру
    // количество ходов, за которые игрок прошел игру
    public void whenGameOver(int cols, int rows, int time, int tryCount) {

        currentPlayer.game_win += 1;
        currentPlayer.time_total += time;

        // Зафиксировать для поля 4 на 4
        if (cols == 4 && rows == 4) {
            // если этот результат быстрее предидущего - то сохранить новый
            if (currentPlayer.best_time_4x4 > time) {
                currentPlayer.best_time_4x4 = time;
            }

            if (currentPlayer.best_try_4x4 > tryCount) {
                currentPlayer.best_try_4x4 = tryCount;
            }
        }
        if (cols == 4 && rows == 5) {
            if (currentPlayer.best_time_4x5 > time) {
                currentPlayer.best_time_4x5 = time;
            }

            if (currentPlayer.best_try_4x5 > tryCount) {
                currentPlayer.best_try_4x5 = tryCount;
            }
        }
        if (cols == 4 && rows == 6) {
            if (currentPlayer.best_time_4x6 > time) {
                currentPlayer.best_time_4x6 = time;
            }

            if (currentPlayer.best_try_4x6 > tryCount) {
                currentPlayer.best_try_4x6 = tryCount;
            }
        }
        if (cols == 5 && rows == 6) {
            if (currentPlayer.best_time_5x6 > time) {
                currentPlayer.best_time_5x6 = time;
            }

            if (currentPlayer.best_try_5x6 > tryCount) {
                currentPlayer.best_try_5x6 = tryCount;
            }
        }
        if (cols == 6 && rows == 6) {
            if (currentPlayer.best_time_6x6 > time) {
                currentPlayer.best_time_6x6 = time;
            }

            if (currentPlayer.best_try_6x6 > tryCount) {
                currentPlayer.best_try_6x6 = tryCount;
            }
        }
    }


    // Создать нового игрока в базе
    public boolean Create(Player newPlayer) {
        long newId = db.Create(newPlayer);
        if (newId == -1)
            return false;
        return true;
    }

    // Получить список увсех игроков
    public List<Player> ReadAll() {
        return db.ReadAll();
    }

    // Получить игрока по id
    public Player Read(long id) {
        return db.Read(id);
    }

    // Обновить игрока в базе
    public boolean Update(Player upPlayer, int id) {
         return false;
    }

    // Удалить игрока из базы по id
//    public int Delete(long id) {
//        //return db.Delete(id);
//    }

    //поиск пользователя по имейлу и паролю
    public boolean CheckUser(String email, String password) {
        currentPlayer = db.CheckUser(email, password);
        if (currentPlayer == null) {
            return false;
        }
        return true;
    }


}
