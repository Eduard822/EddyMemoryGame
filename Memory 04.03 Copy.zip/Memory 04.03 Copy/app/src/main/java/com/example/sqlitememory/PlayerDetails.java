package com.example.sqlitememory;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class PlayerDetails extends AppCompatActivity {

    Button btn_back_details;
    Button btn_delete_details;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_details);

        btn_back_details=(Button) findViewById(R.id.back_details);
        btn_delete_details=(Button) findViewById(R.id.delete_details);
        btn_back_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),RecordActivity.class);
                startActivity(intent);
            }
        });


    }
}